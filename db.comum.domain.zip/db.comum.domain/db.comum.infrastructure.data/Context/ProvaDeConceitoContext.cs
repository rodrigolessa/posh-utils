using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using db.comum.domain.Entities;
using db.comum.infrastructure.data.Context.Mapping;

namespace db.comum.infrastructure.data.Context
{
    public partial class ProvaDeConceitoContext : DbContext
    {
        //static ProvaDeConceitoContext()
        //{
        //    Database.SetInitializer<ProvaDeConceitoContext>(null);
        //}

        public ProvaDeConceitoContext()
            : base("ProvaDeConceitoContext")
        {
            Configuration.LazyLoadingEnabled = false;
        }

        public DbSet<xrole> xroles { get; set; }
        public DbSet<xuser> xusers { get; set; }
        public DbSet<xuserinrole> xuserinroles { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();

            modelBuilder.Properties<string>()
                .Configure(p => p.HasColumnType("varchar"));

            modelBuilder.Properties<string>()
                .Configure(p => p.HasMaxLength(50));

            modelBuilder.Configurations.Add(new xroleMap());
            modelBuilder.Configurations.Add(new xuserMap());
            modelBuilder.Configurations.Add(new xuserinroleMap());
        }
    }
}

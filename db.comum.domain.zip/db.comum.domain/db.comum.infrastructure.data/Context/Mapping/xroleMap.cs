using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using db.comum.domain.Entities;

namespace db.comum.infrastructure.data.Context.Mapping
{
    public class xroleMap : EntityTypeConfiguration<xrole>
    {
        public xroleMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Nome)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("xroles");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Nome).HasColumnName("Nome");
            this.Property(t => t.DataDeInclusao).HasColumnName("DataDeInclusao");
        }
    }
}

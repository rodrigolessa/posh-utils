using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using db.comum.domain.Entities;

namespace db.comum.infrastructure.data.Context.Mapping
{
    public class xuserMap : EntityTypeConfiguration<xuser>
    {
        public xuserMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Titulo)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("xuser");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.Titulo).HasColumnName("Nome");
            this.Property(t => t.DataDeInclusao).HasColumnName("DataDeInclusao");
        }
    }
}

using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using db.comum.domain.Entities;

namespace db.comum.infrastructure.data.Context.Mapping
{
    public class xuserinroleMap : EntityTypeConfiguration<xuserinrole>
    {
        public xuserinroleMap()
        {
            // Primary Key
            this.HasKey(t => new { t.IdUser, t.IdRoles });

            // Properties
            this.Property(t => t.IdUser)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.IdRoles)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("xuserinroles");
            this.Property(t => t.IdUser).HasColumnName("IdUser");
            this.Property(t => t.IdRoles).HasColumnName("IdRoles");
            this.Property(t => t.Peso).HasColumnName("Peso");

            // Relationships
            this.HasRequired(t => t.xrole)
                .WithMany(t => t.xuserinroles)
                .HasForeignKey(d => d.IdRoles);
            this.HasRequired(t => t.xuser)
                .WithMany(t => t.xuserinroles)
                .HasForeignKey(d => d.IdUser);

        }
    }
}

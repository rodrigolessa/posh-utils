﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LDSoft.Comum.Domain;
using LDSoft.Comum.Domain.Entities;
using LDSoft.Comum.Domain.Repositories;

namespace LDSoft.Comum.Infrastructure.Data.Repositories
{
    public class AvisoRepository : Repository<Aviso>, IAvisoRepository
    {
        public AvisoRepository(IQueryableUnitOfWork unitOfWork)
            : base(unitOfWork) { }
    }
}

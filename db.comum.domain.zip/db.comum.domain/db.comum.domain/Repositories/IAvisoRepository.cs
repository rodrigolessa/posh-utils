﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LDSoft.Comum.Domain.Entities;

namespace LDSoft.Comum.Domain.Repositories
{
    public interface IAvisoRepository : IRepository<Aviso>
    {
    }
}

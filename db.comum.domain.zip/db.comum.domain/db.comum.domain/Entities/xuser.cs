using System;
using System.Collections.Generic;

namespace db.comum.domain.Entities
{
    public partial class xuser : EntityBase
    {
        public xuser()
        {
            this.xuserinroles = new List<xuserinrole>();
        }

        public string Titulo { get; set; }
        public virtual ICollection<xuserinrole> xuserinroles { get; set; }
    }
}

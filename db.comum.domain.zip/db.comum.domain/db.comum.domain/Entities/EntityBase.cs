﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace db.comum.domain.Entities
{
    public class EntityBase
    {
        public int Id { get; set; }
        public Nullable<System.DateTime> DataDeInclusao { get; set; }
    }
}

using System;
using System.Collections.Generic;

namespace db.comum.domain.Entities
{
    public partial class xrole : EntityBase
    {
        public xrole()
        {
            this.xuserinroles = new List<xuserinrole>();
        }

        public string Nome { get; set; }
        public virtual ICollection<xuserinrole> xuserinroles { get; set; }
    }
}

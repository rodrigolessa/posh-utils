using System;
using System.Collections.Generic;

namespace db.comum.domain.Entities
{
    public partial class xuserinrole
    {
        public int IdUser { get; set; }
        public int IdRoles { get; set; }
        public Nullable<int> Peso { get; set; }
        public virtual xrole xrole { get; set; }
        public virtual xuser xuser { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LDSoft.Comum.Domain.Entities;

namespace LDSoft.Comum.Domain.Services
{
    public interface IAvisoService
    {
        Aviso Obter(int id);
        List<Aviso> Obter();
        List<Aviso> Obter(string modulo, string nomeDoUsuario);

        List<Aviso> ApolMarca(string nomeDoUsuario);
        List<Aviso> ApolPatente(string nomeDoUsuario);
        List<Aviso> ApolJuridico(string nomeDoUsuario);
        List<Aviso> ApolContrato(string nomeDoUsuario);
        List<Aviso> ApolAdministracao(string nomeDoUsuario);
        List<Aviso> ApolBuscaJunta(string nomeDoUsuario);

        List<Aviso> WebseekAnterioridade(string nomeDoUsuario);
        List<Aviso> WebseekJurisprudencia(string nomeDoUsuario);
        List<Aviso> WebseekEstatistica(string nomeDoUsuario);
    }
}
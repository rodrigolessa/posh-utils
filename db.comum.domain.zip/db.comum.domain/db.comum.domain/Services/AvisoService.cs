﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LDSoft.Comum.Domain.Entities;
using LDSoft.Comum.Domain.Repositories;

namespace LDSoft.Comum.Domain.Services
{
    public class AvisoService : IAvisoService
    {
        #region Atributos

        private readonly IAvisoRepository _repository;
        private readonly string _usuarioDefault;

        #endregion

        #region Construtor

        public AvisoService(IAvisoRepository repository)
        {
            _repository = repository;
            _usuarioDefault = "zz-ld";
        }

        #endregion

        public Aviso Obter(int id)
        {
            return _repository.Get(id);
        }

        public List<Aviso> Obter()
        {
            return _repository.GetAll().ToList();
        }

        /// <summary>
        /// Obtem as mansagens dos módulos informados, mais as do usuário, dentro do período válido para exibição
        /// </summary>
        /// <param name="modulos">Recebe uma string com as siglas dos Módulos separadas por virgula, para representar um array</param>
        /// <param name="nomeDoUsuario">Nome do Usuário do Webseek como string</param>
        /// <returns></returns>
        public List<Aviso> Obter(string modulos, string nomeDoUsuario)
        {
            var a = modulos.Split(',');
            return _repository.GetFiltered(
                x => a.Contains(x.Modulo)
                    && (
                            x.NomeDoUsuario == _usuarioDefault 
                            || (!string.IsNullOrEmpty(nomeDoUsuario) && x.NomeDoUsuario == nomeDoUsuario)
                    )
                    && (
                            x.DiasDeExibicao.HasValue
                            && DbFunctions.AddDays(x.DataDeCadastro, x.DiasDeExibicao.Value) >= DateTime.Today
                    )
            ).ToList();
        }

        #region Apol

        public List<Aviso> ApolMarca(string nomeDoUsuario)
        {
            return this.Obter("T,M", nomeDoUsuario);
        }

        public List<Aviso> ApolPatente(string nomeDoUsuario)
        {
            return this.Obter("T,P", nomeDoUsuario);
        }

        public List<Aviso> ApolJuridico(string nomeDoUsuario)
        {
            return this.Obter("T,C", nomeDoUsuario);
        }

        public List<Aviso> ApolContrato(string nomeDoUsuario)
        {
            return this.Obter("T,V", nomeDoUsuario);
        }

        public List<Aviso> ApolAdministracao(string nomeDoUsuario)
        {
            return this.Obter("T,A", nomeDoUsuario);
        }

        public List<Aviso> ApolBuscaJunta(string nomeDoUsuario)
        {
            return this.Obter("T,BJ", nomeDoUsuario);
        }

        #endregion

        #region Webseek

        public List<Aviso> WebseekAnterioridade(string nomeDoUsuario)
        {
            return this.Obter("WT,W", nomeDoUsuario);
        }

        public List<Aviso> WebseekJurisprudencia(string nomeDoUsuario)
        {
            return this.Obter("WT,WJ", nomeDoUsuario);
        }

        public List<Aviso> WebseekEstatistica(string nomeDoUsuario)
        {
            return this.Obter("WT,WE", nomeDoUsuario);
        }

        #endregion
    }
}

﻿namespace LDSoft.Comum.Infrastructure
{
    public static class Constants
    {
        #region Geral

        public static class Geral
        {
            public static class Acao
            {
                public const string Alterar = "Alterar";
                public const string Excluir = "Excluir";
                public const string Incluir = "Incluir";
                public const string Consultar = "Consultar";
                public const string EnviarEmail = "Enviar E-mail";
            }

            public static class Sistema
            {
                public const string Webseek = "Webseek";
                public const string Apol = "Apol";
                public const string Intranet = "Intranet";
                public const string ModuloConsulta = "Modulo Consulta";

                public static class SubSistema
                {
                    public const string Anterioridade = "Anterioridade";
                    public const string Jurisprudencia = "Jurisprudência";
                    public const string Estatistica = "Estatística";
                    public const string ProgramaDeComputador = "Programa De Computador";
                    public const string BuscaJunta = "Busca Junta";
                    public const string Contrato = "Contrato";
                    public const string Juridico = "Jurídico";

                    public static class Modulo
                    {
                        public const string Marca = "Marca";
                        public const string Patente = "Patente";
                        public const string DI = "Desenho Industrial";
                    }
                }
            }
        }

        #endregion

        #region Marca

        #endregion

        #region Patente

        #endregion

        #region Configuração

        public static class ArquivoDeConfiguracao
        {
        }

        #endregion
    }
}